/*
	Author:Dipayan Das
	Roll:cs1726
	Information Retrival
	Assignment1 Method1
	Prototype version
*/

public class DipayanConstant{

	

	public static String METHOD1_POSTING_LIST_FOLDER_NAME = "method1/";
	
	public static String METHOD1_POSTING_LIST_FILE_NAME = METHOD1_POSTING_LIST_FOLDER_NAME+"method1PostingList.txt";

	public static long KILO_BYTE_SIZE=1024;

	public static long MEGA_BYTE_SIZE=1024*1024;

	public static long GIGA_BYTE_SIZE=1024*1024*1024;
}
